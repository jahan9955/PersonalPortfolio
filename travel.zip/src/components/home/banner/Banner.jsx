import React from 'react'
import src from "/img/showcase-photo3.jpg"
import showcasePhoto1 from "/img/showcase-photo1.jpg"
// import showcasePhoto1 from './img/showcase-photo1.jpg'
// import src from "./assets/img/company-img.jp/g"
// import src3 from "./assets/img/showcase-photo1.jpg"
export default function Banner() {
    return (
        <div className="py-4 px-8 flex flex-col min-h-screen max-w-4xl mx-auto">

            <section className='showcase'>
                <div className="container">
                    <div className="row row1">
                        <div className="img-box">
                            <img src={src} alt="Image Description" />

                        </div>
                        <div className="text-box">
                            <h2 className='lg-heading text-black'>DEGANVY, U.K</h2>
                            <p className='text-gray'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Impedit incidunt nulla a corporis eveniet pariatur maiores, id quis, totam dolore praesentium facere consequatur rem, fuga minus! Rerum, dolorem praesentium. Nemo?</p>
                            <a href="./about.html" className='btn btn-secondary'>More</a>
                        </div>
                    </div>
                    <div className="row row2">
                        <div className="img-box">
                            <img src={showcasePhoto1} alt="Image Description" />

                        </div>
                        <div className="text-box">
                            <h2 className='lg-heading text-black'>DESERT, EGYPT</h2>
                            <p className='text-gray'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Maiores, amet ratione, quas laborum porro, explicabo vero ipsum laudantium nesciunt eos illum pariatur obcaecati fugiat asperiores nulla adipisci. Porro, atque itaque.</p>
                            <a href="./about.html" className='btn btn-secondary'>More</a>
                        </div>
                    </div>
                </div>
            </section>
            {/* <Header />
        <Outlet /> */}
        </div>
    )
}
