import React from 'react'

import Navbar from './nav/Navbar'

import Footer from './footer/Footer'
import Banner from './banner/banner'
import Feature from './feature/feature'

export default function Home() {
  return (
    <div>
      <Navbar />
      <Banner />
      <Feature />
      <Footer />
    </div>
  )
}
