import './App.css'
import About from './components/about/About';
import Contact from './components/contact/Contact';
import Home from './components/home/Home.jsx'
import { Route, Routes } from "react-router-dom";

function App() {


  return (
    <>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/about" element={<About />}></Route>
        <Route path="/contact" element={<Contact />}></Route>
      </Routes>

    </>
  )
}

export default App
